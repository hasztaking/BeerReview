﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;


namespace BeerReview.Entity
{
    public class Beer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Brad { get; set; }
        public string Review { get; set; }
        public int Rating { get; set; }
        public DateTime CreatedAt { get; set; }
        public string ImgageData { get; set; } = string.Empty;
        [NotMapped]
        public IFormFile? ImageFile { get; set; } 
    }
}
