﻿using Microsoft.EntityFrameworkCore;
using BeerReview.Entity;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Configuration;
namespace BeerReview.Services
{
    public class ApplicationDbContext(DbContextOptions options) : DbContext(options)
    {
        public DbSet<BeerReview.Entity.Beer> beer { get; set; }
    }
}
