using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BeerReview;
using BeerReview.Services;
using BeerReview.Entity;
namespace BeerReview.Pages.Beers
{
    public class DeleteReviewModel : PageModel
    {
        private const string PageName = "Index";
        private readonly ApplicationDbContext _context;

        public DeleteReviewModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Beer Beer { get; set; }



        public IActionResult OnGet(int id)
        {
            Beer = _context.beer.FirstOrDefault(b => b.Id == id);

            if (Beer == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult Onpost(int id)
        {
            var BeerToDelete = _context.beer.FirstOrDefault(b => b.Id == id);

            if (BeerToDelete == null)
            {
                return NotFound();
            }

            _context.beer.Remove(BeerToDelete);
            _context.SaveChanges();

            return RedirectToPage(PageName);
        }
    }
}
