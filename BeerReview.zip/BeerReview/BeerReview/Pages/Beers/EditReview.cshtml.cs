using BeerReview.Entity;
using BeerReview.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeerReview.Pages.Beers
{
    public class EditReviewModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public EditReviewModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public  Beer Beer{ get; set; }

        public IActionResult OnGet(int id)
        {
            Beer = _context.beer.FirstOrDefault(b => b.Id == id);

            if (Beer == null)
            {
                return NotFound();
            }
            return Page();
        }

        public IActionResult OnPost(int id) {
            if (!ModelState.IsValid) {
                return Page();
            }

            var BeerInDB = _context.beer.FirstOrDefault(b => b.Id == Beer.Id);

            if (BeerInDB == null) { 
                return NotFound();
            }
            
            BeerInDB.Name = Beer.Name;
            BeerInDB.Brad = Beer.Brad;
            BeerInDB.Review = Beer.Review;
            BeerInDB.Rating = Beer.Rating;

            if (Beer.ImageFile != null)
            {
                using (var stream = Beer.ImageFile.OpenReadStream())
                using (var ms = new MemoryStream())
                {
                    stream.CopyTo(ms);
                    byte [] bytes = ms.ToArray ();
                    BeerInDB.ImgageData = Convert.ToBase64String(bytes);
                }
            }
            _context.SaveChanges();

            return RedirectToPage("Index");

        }
    }
}
