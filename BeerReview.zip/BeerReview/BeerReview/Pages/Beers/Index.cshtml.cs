using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BeerReview.Entity;
using BeerReview.Services;  
using Microsoft.EntityFrameworkCore;


namespace BeerReview.Pages.Beers
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Beer> BeerList { get; set; }

        public void OnGet()
        {
            if (_context.beer != null)
            {
                BeerList = _context.beer.ToList();
            }
        }
    }
}
