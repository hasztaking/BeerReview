using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BeerReview.Entity;
using BeerReview.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;


namespace BeerReview.Pages.Beers
{
    public class AddReviewModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        [BindProperty]

        public Beer Beer { get; set; }

        public AddReviewModel(ApplicationDbContext context) => _context = context;


        public IActionResult OnGet()
        {
            return Page();
        }

        public IActionResult OnPost()
        {
            byte[] bytes = null;

            if (Beer.ImageFile != null)
            {
                using (Stream fs = Beer.ImageFile.OpenReadStream())
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        bytes = br.ReadBytes((Int32)fs.Length);
                    } 
                }
                Beer.ImgageData = Convert.ToBase64String(bytes,0,bytes.Length);
            }

            Beer.CreatedAt = DateTime.Now;


            _context.beer.Add(Beer);
            _context.SaveChanges();

            return RedirectToPage("Index");
        }

    }
}
